<?php 
$host ="localhost";
$user ="root";
$pass ="";
$db ="belajar";

$koneksi =mysqli_connect($host, $user, $pass, $db);

 ?>