<?php include 'koneksi.php' ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Mmebuat Select Option Dinamis Dengan Ajax</title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" crossorigin="anonymous">
</head>
<body>
	<div class="container">
		<center><h2>Select Option Dinamis Dengan Ajax</h2></center>
		<form action="proses.php" method="post">
			<div class="form-group">
				<label>FAKULTAS:</label>
				<select class="form-control" name="fakultas" id="fakultas" required>
					<option value="">--Fakultas--</option>
					<?php
					$fakultas = mysqli_query($koneksi,"select * from tbl_fakultas");
					while($f = mysqli_fetch_array($fakultas)){
						?>
						<option value="<?php echo $f['fakultas_id'] ?>"><?php echo $f['fakultas_nama']; ?></option>
						<?php
					}
					?>
				</select>
			</div>
			<div class="form-group">
				<label>JURUSAN</label>
				<select class="form-control" name="jurusan" id="jurusan" required>
				</select>
			</div>

			<div class="form-group">
				<label>Alamat</label>
				<input type="text" name="alamat" class="form-control" required>
			</div>			
			<button type="submit" class="btn btn-primary">Submit</button>
		</form>
	</div>
	<table class="table table-borderd">
		<thead>
			<tr>
				<th>No</th>
				<th>Nama Fakultas</th>
				<th>Nama Jurusan</th>
				<th>Alamat</th>
				<th>Aksi</th>
			</tr>
		</thead>
		<tbody>
			<?php 
			$no=1;
			$tampil =mysqli_query($koneksi, "SELECT tbl_fakultas.fakultas_nama, tb_hasil.jurusan, tb_hasil.alamat, tb_hasil.id_hasil FROM tbl_fakultas INNER JOIN tb_hasil ON tbl_fakultas.fakultas_id = tb_hasil.fakultas");
			while ($data =mysqli_fetch_array($tampil)) { ?>
				<tr>
					<td><?php echo $no++; ?></td>
					<td><?php echo $data['fakultas_nama']; ?></td>
					<td><?php echo $data['jurusan']; ?></td>
					<td><?php echo $data['alamat']; ?></td>
					<td><a href="hapus_data.php?id=<?php echo $data['id_hasil']; ?>">hapus</a></td>
				</tr>
			<?php } ?>

		</tbody>
	</table>

	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	<script type="text/javascript">
		$('#fakultas').change(function(){ 
			var fakultas = $(this).val(); 
			$.ajax({
				type	: 'POST', 
				url		: 'ajax_jurusan.php', 
				data	: 'fakultas_nama=' + fakultas, 
				success:function(response) { 
					$('#jurusan').html(response); 
				}
			});
		});
	</script>
</body>
</html>