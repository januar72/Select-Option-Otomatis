<?php 
include 'koneksi.php';
$id =$_GET['id'];

$hapus =mysqli_query($koneksi, "DELETE FROM tb_hasil WHERE id_hasil='$id'");
header("location:index.php");
exit();
 ?>