<?php 
include 'koneksi.php';

$fakultas =$_POST['fakultas'];
$jurusan =$_POST['jurusan'];
$alamat =$_POST['alamat'];


$simpan =mysqli_query($koneksi, "INSERT INTO `tb_hasil` (`id_hasil`,`fakultas`,`jurusan`,`alamat`) VALUES (null, '$fakultas','$jurusan','$alamat')");
header("location:index.php");
exit();

 ?>